<h2>WELCOME ADMIN</h2>
<pre><?php print_r($_SESSION);?></pre>