<?php
session_start();
//koneksi database
include 'koneksi.php';
?>
<!DOCTYPE html>
<html> 
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Buka Toko</title>
	<link rel="stylesheet" type="text/css" href="admin/assets/css/bootstrap.css">
	<script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>

<body style="background-color: #778899;">
	<div class="container" style="background-color: whitesmoke;">
  <div class="container text-left" style="color: black;">
    <h1><b>Bukatoko</b></h1>      
    <p>menjual berbagai merk baju trend</p>
  </div>
</div>
<?php include 'menu.php'; ?>
<!--konten-->
<section class="konten">
	<div class="container">
		<h1 style="text-align: center; color: white; font-family: sans-serif; padding-bottom: 30px;">KATALOG BAJU</h1>
		<div class="row">
			<?php $ambil=$koneksi->query("SELECT * FROM produk");?>
			<?php while($perproduk = $ambil->fetch_assoc()){?>

		<div class="col-md-4">
			<div class="thumbnail">
				<img src="foto_produk/<?php echo $perproduk['foto_produk']; ?>" width="300">
				<div class="caption">
					<h3><?php echo $perproduk['nama_produk'];?></h3>
					<h5><?php echo number_format($perproduk['harga_produk']);?></h5>
					<a href="beli.php?id=<?php echo $perproduk['id_produk'];?>" class="btn btn-primary">Beli</a>
					<a href="detail.php?id=<?php echo $perproduk["id_produk"];?>" class="btn btn-default">detail</a>
				</div>
			</div>
		</div>
		<?php }?>

	</div>
	</div>
</section>


</body>
<footer style="bottom: 50px;width: 100%;background: #111; color: white;">
<div class="main-content" style="display: flex;">
	<div class="left box" style="flex-basis: 50%; padding: 10px 20px;">
		<h2>About us</h2>
		<div class="content">
			<p>buka toko menyediakan banyak sekali baju branded yang harganya merakyat dan pasti tidak menguras kantong

			</p>
			<div class="social">
				<a href="https://www.facebook.com/profile.php?id=100011592488369"><span class="fab fa-facebook-f"></span></a>
				<a href="https://www.instagram.com/aripo_real/"><span class="fab fa-instagram"></span></a>
				<a href="https://www.youtube.com/channel/UC_A5OLSq1HvnlN-Lwx5mMTA"><span class="fab fa-youtube"></span></a>
			</div>
		</div>
	</div>
	<div class="center box" style="flex-basis: 50%; padding: 10px 20px;">
		<h2>addreas</h2>
		<div class="content">
			<div class="place">
				<span class="fas fa-map-marker-alt"></span>
				<span class="text">Sumbermulyo, Sangklur</span>
			</div>
			<div class="phone">
				<span class="fas fa-phone-alt"></span>
				<span class="text">+6285-80388-6761</span>
		</div>
		<div class="place">
				<span class="fas fa-envelope"></span>
				<span class="text">syamsulmuarif290@gmail.com</span>
				</div>
			</div>
		</div>
		<div class="right box" style="flex-basis: 50%; padding: 10px 20px;">
			<h2>Contack us</h2>
			<div class="content">
				<form action="#">
					<div class="email">
						<div class="text">Email </div>
						<input type="email" name="email" required>
					</div>

					<div class="msg">
						<div class="text">mesage</div>
						<textarea rows="2" cols="25"></textarea>
					</div>
					<div class="btn btn-default">
					<button type="submit">send</button>
					</div>	
					</div>


				</form>

			</div>
			
		</div>



	</div>
</div>
</footer>
</html>